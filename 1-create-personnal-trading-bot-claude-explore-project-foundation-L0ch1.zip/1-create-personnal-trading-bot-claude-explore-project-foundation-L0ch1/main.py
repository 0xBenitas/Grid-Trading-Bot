"""Grid Trading Bot CLI.

Usage:
    python main.py backtest
    python main.py backtest --symbol BTCUSDT --grids 30 --investment 5000
    python main.py optimize --symbol ETHUSDT --quick
    python main.py live
    python main.py dashboard
"""

import argparse
import os
import sys
from pathlib import Path

import yaml
from dotenv import load_dotenv
from loguru import logger

load_dotenv()


def load_config(config_path: str = "config/settings.yaml") -> dict:
    path = Path(config_path)
    if not path.exists():
        logger.error(f"Config not found: {config_path}")
        sys.exit(1)
    with open(path) as f:
        return yaml.safe_load(f)


def _build_grid_config(args, config) -> "GridConfig":
    from src.core.models import GridConfig

    grid_cfg = config.get("grid", {})
    return GridConfig(
        symbol=args.symbol or grid_cfg.get("symbol", "ETHUSDT"),
        num_grids=args.grids or grid_cfg.get("num_grids", 20),
        total_investment=args.investment or grid_cfg.get("total_investment", 1000),
        use_atr_spacing=grid_cfg.get("use_atr_spacing", True),
        atr_period=grid_cfg.get("atr_period", 14),
        atr_multiplier=args.atr_mult or grid_cfg.get("atr_multiplier", 2.0),
        regime_filter=grid_cfg.get("regime_filter", True),
        chop_period=grid_cfg.get("chop_period", 14),
        chop_threshold=grid_cfg.get("chop_threshold", 50.0),
        rebalance_on_breakout=grid_cfg.get("rebalance_on_breakout", True),
        lower_price=grid_cfg.get("lower_price", 0),
        upper_price=grid_cfg.get("upper_price", 0),
        # Optimization settings
        spacing=grid_cfg.get("spacing", "geometric"),
        weighted_qty=grid_cfg.get("weighted_qty", True),
        rsi_filter=grid_cfg.get("rsi_filter", True),
        rsi_period=grid_cfg.get("rsi_period", 14),
        rsi_oversold=grid_cfg.get("rsi_oversold", 25.0),
        rsi_overbought=grid_cfg.get("rsi_overbought", 75.0),
        rebalance_cooldown=grid_cfg.get("rebalance_cooldown", 6),
        trailing_shift=grid_cfg.get("trailing_shift", True),
        trailing_shift_pct=grid_cfg.get("trailing_shift_pct", 0.02),
    )


def cmd_backtest(args, config):
    from src.data.fetcher import fetch_historical
    from src.engine.backtester import GridBacktester

    grid_config = _build_grid_config(args, config)
    start_date = args.start or config.get("backtest", {}).get("start_date", "01 January 2024")
    fee_rate = config.get("risk", {}).get("fee_rate", 0.001)
    snapshot_interval = config.get("backtest", {}).get("snapshot_interval", 24)

    logger.info(f"Grid Backtest: {grid_config.symbol} from {start_date}")
    logger.info(f"Grids={grid_config.num_grids}, Investment={grid_config.total_investment} USDT")
    logger.info(f"Spacing={grid_config.spacing}, Weighted={grid_config.weighted_qty}, RSI={grid_config.rsi_filter}")

    df = fetch_historical(symbol=grid_config.symbol, start_date=start_date)

    bt = GridBacktester(grid_config, fee_rate=fee_rate, snapshot_interval=snapshot_interval)
    result = bt.run(df)

    print("\n" + "=" * 65)
    print(f"  GRID BOT BACKTEST — {grid_config.symbol}")
    print(f"  {result.start_date.strftime('%Y-%m-%d')} -> {result.end_date.strftime('%Y-%m-%d')} ({result.duration_days:.0f} days)")
    print("=" * 65)
    print(f"  Investment:             {result.initial_investment:>12.2f} USDT")
    print(f"  Final Value:            {result.final_value:>12.2f} USDT")
    print(f"  Grid Profit:            {result.total_profit:>+12.2f} USDT")
    print(f"  ROI:                    {result.roi_pct:>+11.2f}%")
    print(f"  Annualized ROI:         {result.annualized_roi_pct:>+11.2f}%")
    print(f"  Buy & Hold:             {result.buy_hold_roi_pct:>+11.2f}%")
    print(f"  vs Buy & Hold:          {result.vs_hold_pct:>+11.2f}%")
    print("-" * 65)
    print(f"  Completed Cycles:       {result.completed_cycles:>12d}")
    print(f"  Avg Profit/Cycle:       {result.avg_profit_per_cycle:>12.4f} USDT")
    print(f"  Avg Return/Cycle:       {result.avg_profit_pct_per_cycle:>11.4f}%")
    print(f"  Total Fees:             {result.total_fees:>12.2f} USDT")
    print("-" * 65)
    print(f"  Max Drawdown:           {result.max_drawdown_pct:>11.2f}%")
    print(f"  Max Coin Exposure:      {result.max_coin_exposure_pct:>11.2f}%")
    print(f"  Grid Uptime:            {result.uptime_pct:>11.1f}%")
    print("=" * 65)


def cmd_optimize(args, config):
    from src.data.fetcher import fetch_historical
    from src.engine.optimizer import optimize, format_report, QUICK_SEARCH_SPACE

    grid_config = _build_grid_config(args, config)
    start_date = args.start or config.get("backtest", {}).get("start_date", "01 January 2024")
    fee_rate = config.get("risk", {}).get("fee_rate", 0.001)

    logger.info(f"Optimizing: {grid_config.symbol} from {start_date}")

    df = fetch_historical(symbol=grid_config.symbol, start_date=start_date)

    search_space = QUICK_SEARCH_SPACE if args.quick else None
    report = optimize(df, grid_config, search_space=search_space, fee_rate=fee_rate)
    print(format_report(report))


def cmd_live(args, config):
    from src.exchange.binance_client import BinanceExchangeClient
    from src.engine.live_trader import LiveGridTrader
    from src.engine.risk_manager import RiskConfig

    api_key = os.getenv("BINANCE_API_KEY", "")
    api_secret = os.getenv("BINANCE_API_SECRET", "")

    if not api_key or not api_secret:
        logger.error("Set BINANCE_API_KEY and BINANCE_API_SECRET in .env")
        sys.exit(1)

    grid_config = _build_grid_config(args, config)
    risk_cfg = config.get("risk", {})
    risk_config = RiskConfig(
        max_drawdown_pct=risk_cfg.get("max_drawdown_pct", 0.15),
        max_position_pct=risk_cfg.get("max_position_pct", 0.50),
        max_single_order_pct=risk_cfg.get("max_single_order_pct", 0.05),
        daily_loss_limit=risk_cfg.get("daily_loss_limit", 0.05),
    )

    exchange = BinanceExchangeClient(
        api_key=api_key,
        api_secret=api_secret,
        testnet=config.get("exchange", {}).get("testnet", True),
    )

    trader = LiveGridTrader(
        exchange=exchange,
        grid_config=grid_config,
        risk_config=risk_config,
        fee_rate=risk_cfg.get("fee_rate", 0.001),
        interval_seconds=config.get("live", {}).get("interval_seconds", 60),
    )

    trader.run()


def cmd_dashboard(args, config):
    from src.dashboard.app import create_app

    host = config.get("dashboard", {}).get("host", "127.0.0.1")
    port = config.get("dashboard", {}).get("port", 8050)
    logger.info(f"Dashboard: http://{host}:{port}")
    app = create_app(config)
    app.run(host=host, port=port, debug=True)


def main():
    parser = argparse.ArgumentParser(description="Grid Trading Bot")
    parser.add_argument("--config", default="config/settings.yaml")
    subparsers = parser.add_subparsers(dest="command")

    # Backtest
    bt = subparsers.add_parser("backtest", help="Run grid bot backtest")
    bt.add_argument("--symbol", type=str, help="Trading pair")
    bt.add_argument("--grids", type=int, help="Number of grid lines")
    bt.add_argument("--investment", type=float, help="Total investment in USDT")
    bt.add_argument("--atr-mult", type=float, help="ATR multiplier for grid range")
    bt.add_argument("--start", type=str, help="Start date")

    # Optimize
    opt = subparsers.add_parser("optimize", help="Find best grid parameters")
    opt.add_argument("--symbol", type=str, help="Trading pair")
    opt.add_argument("--grids", type=int, help="Base grid count")
    opt.add_argument("--investment", type=float, help="Total investment in USDT")
    opt.add_argument("--atr-mult", type=float, help="Base ATR multiplier")
    opt.add_argument("--start", type=str, help="Start date")
    opt.add_argument("--quick", action="store_true", help="Quick optimization (fewer combos)")

    # Live
    live = subparsers.add_parser("live", help="Run live grid bot")
    live.add_argument("--symbol", type=str)
    live.add_argument("--grids", type=int)
    live.add_argument("--investment", type=float)
    live.add_argument("--atr-mult", type=float)

    # Dashboard
    subparsers.add_parser("dashboard", help="Launch web dashboard")

    args = parser.parse_args()
    config = load_config(args.config)

    if args.command == "backtest":
        cmd_backtest(args, config)
    elif args.command == "optimize":
        cmd_optimize(args, config)
    elif args.command == "live":
        cmd_live(args, config)
    elif args.command == "dashboard":
        cmd_dashboard(args, config)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
