"""Grid Bot Backtester.

Simulates the grid bot on historical OHLCV data.
Uses candle high/low to simulate limit order fills.
Supports all optimization features: RSI filter, regime filter,
geometric spacing, weighted quantities, trailing shift.
"""

from datetime import datetime

import pandas as pd
from loguru import logger

from src.core.models import GridConfig, BacktestResult, GridSnapshot
from src.data.indicators import add_atr, add_choppiness, add_rsi
from src.engine.grid_engine import GridEngine


class GridBacktester:
    """Backtests a grid bot on historical data."""

    def __init__(
        self,
        config: GridConfig,
        fee_rate: float = 0.001,
        snapshot_interval: int = 24,  # snapshot every N candles
    ):
        self.config = config
        self.fee_rate = fee_rate
        self.snapshot_interval = snapshot_interval

    def run(self, df: pd.DataFrame) -> BacktestResult:
        """Run grid bot backtest on OHLCV DataFrame.

        The grid range is auto-calculated from ATR if use_atr_spacing=True,
        otherwise uses config.lower_price / config.upper_price.
        """
        df = df.copy()

        # Add indicators for regime detection and grid sizing
        df = add_atr(df, self.config.atr_period)
        df = add_choppiness(df, self.config.chop_period)

        # Add RSI for anti-crash filter
        if self.config.rsi_filter:
            df = add_rsi(df, window=self.config.rsi_period)

        # Find first row with valid ATR > 0
        valid_atr = df[df["ATR"].notna() & (df["ATR"] > 0)]
        if valid_atr.empty:
            raise ValueError("Not enough data to compute ATR > 0")

        start_idx = valid_atr.index[0]
        start_pos = df.index.get_loc(start_idx)
        if isinstance(start_pos, slice):
            start_pos = start_pos.start

        # Calculate initial grid bounds
        first_row = df.iloc[start_pos]
        current_price = first_row["close"]

        if self.config.use_atr_spacing:
            atr = first_row["ATR"]
            half_range = atr * self.config.atr_multiplier
            lower = current_price - half_range
            upper = current_price + half_range
        else:
            lower = self.config.lower_price
            upper = self.config.upper_price

        # Initialize engine
        engine = GridEngine(self.config)
        engine.initialize(current_price, lower, upper)
        original_investment = self.config.total_investment

        # Tracking
        equity_curve = []
        equity_dates = []
        snapshots = []
        max_equity = original_investment
        max_drawdown = 0.0
        max_coin_exposure = 0.0
        max_unrealized_loss = 0.0
        active_candles = 0
        total_candles = 0

        # Simulate
        for i in range(start_pos, len(df)):
            row = df.iloc[i]
            timestamp = df.index[i]
            total_candles += 1

            close = row["close"]
            low = row["low"]
            high = row["high"]
            atr = row["ATR"] if pd.notna(row["ATR"]) else 0
            chop = row["CHOP"] if pd.notna(row["CHOP"]) else 50

            # Update RSI
            if self.config.rsi_filter and "RSI" in df.columns:
                rsi = row["RSI"] if pd.notna(row["RSI"]) else 50
                engine.update_rsi(rsi)

            # Update regime
            if self.config.regime_filter:
                engine.update_regime(chop, atr)

            # Check for breakout / rebalance
            if engine.levels and self.config.rebalance_on_breakout:
                if close < engine.levels[0] or close > engine.levels[-1]:
                    engine.current_atr = atr
                    engine.rebalance(close)

            # Process candle
            engine.update(close, low, high, timestamp, self.fee_rate)

            if engine.state.value == "running":
                active_candles += 1

            # Track equity
            equity = engine.value_at_price(close)
            equity_curve.append(equity)
            equity_dates.append(timestamp)

            # Track drawdown
            if equity > max_equity:
                max_equity = equity
            dd = (equity - max_equity) / max_equity if max_equity > 0 else 0
            if dd < max_drawdown:
                max_drawdown = dd

            # Track exposure
            coin_value = engine.coin_held * close
            if coin_value > 0:
                exposure = coin_value / equity if equity > 0 else 0
                if exposure > max_coin_exposure:
                    max_coin_exposure = exposure

            # Track unrealized loss
            unrealized = coin_value - (original_investment - engine.fiat_held)
            if unrealized < max_unrealized_loss:
                max_unrealized_loss = unrealized

            # Periodic snapshots
            if total_candles % self.snapshot_interval == 0:
                snapshots.append(engine.get_snapshot(close, timestamp))

        # Final stats
        final_value = engine.value_at_price(df.iloc[-1]["close"])
        total_profit = engine.total_profit
        total_fees = engine.total_fees

        roi = ((final_value - original_investment) / original_investment * 100
               if original_investment > 0 else 0)

        # Duration
        start_date = df.index[start_pos]
        end_date = df.index[-1]
        duration = (end_date - start_date).total_seconds() / 86400
        annualized_roi = (roi / duration * 365) if duration > 0 else 0

        # Buy and hold
        first_close = df.iloc[start_pos]["close"]
        last_close = df.iloc[-1]["close"]
        buy_hold_roi = ((last_close - first_close) / first_close * 100)

        # Average per cycle
        n_cycles = len(engine.completed_orders)
        avg_profit = total_profit / n_cycles if n_cycles > 0 else 0
        avg_profit_pct = sum(o.return_pct for o in engine.completed_orders) / n_cycles if n_cycles > 0 else 0

        uptime = active_candles / total_candles * 100 if total_candles > 0 else 0

        return BacktestResult(
            initial_investment=original_investment,
            final_value=round(final_value, 2),
            total_profit=round(total_profit, 2),
            total_fees=round(total_fees, 2),
            roi_pct=round(roi, 2),
            annualized_roi_pct=round(annualized_roi, 2),
            buy_hold_roi_pct=round(buy_hold_roi, 2),
            vs_hold_pct=round(roi - buy_hold_roi, 2),
            completed_cycles=n_cycles,
            total_buy_fills=n_cycles,
            total_sell_fills=n_cycles,
            avg_profit_per_cycle=round(avg_profit, 4),
            avg_profit_pct_per_cycle=round(avg_profit_pct, 4),
            max_drawdown_pct=round(max_drawdown * 100, 2),
            max_coin_exposure_pct=round(max_coin_exposure * 100, 2),
            max_unrealized_loss=round(max_unrealized_loss, 2),
            start_date=start_date,
            end_date=end_date,
            duration_days=round(duration, 1),
            uptime_pct=round(uptime, 1),
            completed_orders=engine.completed_orders,
            equity_curve=equity_curve,
            equity_dates=equity_dates,
            snapshots=snapshots,
        )
