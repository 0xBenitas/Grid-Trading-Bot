"""Portfolio tracking for the Grid Bot."""

from dataclasses import dataclass, field
from datetime import datetime

import pandas as pd
from loguru import logger

from src.core.models import GridOrder


@dataclass
class Portfolio:
    """Tracks grid bot portfolio state and trade history."""

    fiat_balance: float = 0.0
    coin_balance: float = 0.0
    fiat_symbol: str = "USDT"
    coin_symbol: str = "BTC"
    completed_orders: list[GridOrder] = field(default_factory=list)

    def value_at_price(self, price: float) -> float:
        return self.fiat_balance + self.coin_balance * price

    def add_completed_order(self, order: GridOrder) -> None:
        self.completed_orders.append(order)

    def summary(self, current_price: float) -> dict:
        total = self.value_at_price(current_price)
        profits = [o.net_profit for o in self.completed_orders]
        return {
            "fiat": round(self.fiat_balance, 2),
            "coin": round(self.coin_balance, 8),
            "total_value": round(total, 2),
            "completed_cycles": len(self.completed_orders),
            "total_profit": round(sum(profits), 2) if profits else 0,
            "avg_profit": round(sum(profits) / len(profits), 4) if profits else 0,
        }

    def to_dataframe(self) -> pd.DataFrame:
        if not self.completed_orders:
            return pd.DataFrame()
        records = []
        for o in self.completed_orders:
            records.append({
                "buy_time": o.buy_time,
                "sell_time": o.sell_time,
                "buy_price": o.buy_price,
                "sell_price": o.sell_price,
                "quantity": o.quantity,
                "gross_profit": o.gross_profit,
                "net_profit": o.net_profit,
                "return_pct": o.return_pct,
                "buy_fee": o.buy_fee,
                "sell_fee": o.sell_fee,
            })
        return pd.DataFrame(records)
