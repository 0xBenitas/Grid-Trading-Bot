"""Live Grid Bot Trader.

Runs the grid bot on a real exchange via the ExchangeClient interface.
"""

import time
from datetime import datetime

from loguru import logger

from src.core.models import GridConfig
from src.data.indicators import add_atr, add_choppiness, add_rsi
from src.engine.grid_engine import GridEngine
from src.engine.risk_manager import RiskManager, RiskConfig
from src.exchange.base import ExchangeClient


class LiveGridTrader:
    """Live trading engine for the grid bot."""

    def __init__(
        self,
        exchange: ExchangeClient,
        grid_config: GridConfig,
        risk_config: RiskConfig,
        fee_rate: float = 0.001,
        interval_seconds: int = 60,  # check every minute
    ):
        self.exchange = exchange
        self.grid_config = grid_config
        self.risk_manager = RiskManager(risk_config, grid_config.total_investment)
        self.engine = GridEngine(grid_config)
        self.fee_rate = fee_rate
        self.interval_seconds = interval_seconds

    def start(self) -> None:
        """Initialize and start the grid bot."""
        logger.info(f"Starting Grid Bot on {self.grid_config.symbol}")

        # Fetch recent data for ATR calculation
        df = self.exchange.get_klines(
            self.grid_config.symbol, "1h", limit=100,
        )
        df = add_atr(df, self.grid_config.atr_period)
        df = add_choppiness(df, self.grid_config.chop_period)
        if self.grid_config.rsi_filter:
            df = add_rsi(df, window=self.grid_config.rsi_period)

        current_price = df.iloc[-1]["close"]
        atr = df["ATR"].iloc[-1]

        # Auto-calculate grid bounds from ATR
        if self.grid_config.use_atr_spacing:
            half_range = atr * self.grid_config.atr_multiplier
            lower = current_price - half_range
            upper = current_price + half_range
        else:
            lower = self.grid_config.lower_price
            upper = self.grid_config.upper_price

        self.engine.initialize(current_price, lower, upper)

        logger.info(f"Grid: [{lower:.2f} - {upper:.2f}], {self.grid_config.num_grids} levels")
        logger.info(f"Investment: {self.grid_config.total_investment} USDT")
        logger.info(f"Spacing: {self.grid_config.spacing}, Weighted: {self.grid_config.weighted_qty}")

    def tick(self) -> None:
        """One iteration of the trading loop."""
        try:
            # Get current data
            df = self.exchange.get_klines(
                self.grid_config.symbol, "1h", limit=50,
            )
            df = add_atr(df, self.grid_config.atr_period)
            df = add_choppiness(df, self.grid_config.chop_period)
            if self.grid_config.rsi_filter:
                df = add_rsi(df, window=self.grid_config.rsi_period)

            row = df.iloc[-1]
            current_price = row["close"]
            low = row["low"]
            high = row["high"]
            atr = row["ATR"] if not _isnan(row["ATR"]) else 0
            chop = row["CHOP"] if not _isnan(row["CHOP"]) else 50

            now = datetime.now()

            # Risk check
            total_value = self.engine.value_at_price(current_price)
            coin_value = self.engine.coin_held * current_price
            if not self.risk_manager.check(total_value, coin_value):
                logger.warning("Risk manager blocked trading")
                return

            # Update RSI
            if self.grid_config.rsi_filter and "RSI" in df.columns:
                rsi = row["RSI"] if not _isnan(row["RSI"]) else 50
                self.engine.update_rsi(rsi)

            # Update regime
            self.engine.update_regime(chop, atr)

            # Check for rebalance
            if self.engine.levels:
                if current_price < self.engine.levels[0] or current_price > self.engine.levels[-1]:
                    self.engine.current_atr = atr
                    self.engine.rebalance(current_price)

            # Process
            completions = self.engine.update(current_price, low, high, now, self.fee_rate)

            for order in completions:
                logger.info(
                    f"Cycle completed: buy@{order.buy_price:.2f} -> sell@{order.sell_price:.2f} "
                    f"profit={order.net_profit:.4f}"
                )

            # Log status
            snapshot = self.engine.get_snapshot(current_price, now)
            logger.info(
                f"Price={current_price:.2f} | State={snapshot.state} | "
                f"Cycles={snapshot.filled_cycles} | Profit={snapshot.total_profit:.2f} | "
                f"ROI={snapshot.roi_pct:.2f}% | Regime={snapshot.market_regime} | "
                f"RSI={self.engine.current_rsi:.1f}"
            )

        except Exception as e:
            logger.error(f"Tick error: {e}")

    def run(self) -> None:
        """Main trading loop."""
        self.start()
        logger.info(f"Running (tick every {self.interval_seconds}s)...")
        while True:
            self.tick()
            time.sleep(self.interval_seconds)


def _isnan(val) -> bool:
    try:
        import math
        return math.isnan(val)
    except (TypeError, ValueError):
        return True
