"""Risk Management for the Grid Bot.

Enforces position limits, max drawdown, and exposure rules.
"""

from dataclasses import dataclass
from loguru import logger

from src.core.exceptions import CircuitBreakerError


@dataclass
class RiskConfig:
    """Risk management parameters."""
    max_drawdown_pct: float = 0.15        # halt if portfolio drops 15%
    max_position_pct: float = 0.50        # max 50% of capital in coin
    max_single_order_pct: float = 0.05    # max 5% of capital per order
    daily_loss_limit: float = 0.05        # halt if daily loss > 5%


class RiskManager:
    """Monitors and enforces risk limits."""

    def __init__(self, config: RiskConfig, initial_capital: float):
        self.config = config
        self.initial_capital = initial_capital
        self.peak_value = initial_capital
        self.daily_start_value = initial_capital
        self.halted = False
        self.halt_reason = ""

    def check(self, current_value: float, coin_value: float) -> bool:
        """Check all risk limits. Returns True if trading is allowed.

        Raises CircuitBreakerError if a limit is breached.
        """
        if self.halted:
            return False

        # Max drawdown from peak
        if current_value > self.peak_value:
            self.peak_value = current_value

        drawdown = (self.peak_value - current_value) / self.peak_value
        if drawdown > self.config.max_drawdown_pct:
            self._halt(f"Max drawdown breached: {drawdown:.1%} > {self.config.max_drawdown_pct:.1%}")
            return False

        # Max position exposure
        if current_value > 0:
            position_pct = coin_value / current_value
            if position_pct > self.config.max_position_pct:
                logger.warning(f"Position exposure {position_pct:.1%} > limit {self.config.max_position_pct:.1%}")
                return False

        # Daily loss limit
        daily_change = (current_value - self.daily_start_value) / self.daily_start_value
        if daily_change < -self.config.daily_loss_limit:
            self._halt(f"Daily loss limit breached: {daily_change:.1%}")
            return False

        return True

    def validate_order_size(self, order_value: float, current_capital: float) -> bool:
        """Check if a single order is within size limits."""
        if current_capital <= 0:
            return False
        pct = order_value / current_capital
        if pct > self.config.max_single_order_pct:
            logger.debug(f"Order too large: {pct:.1%} > {self.config.max_single_order_pct:.1%}")
            return False
        return True

    def new_day(self, current_value: float) -> None:
        """Reset daily tracking."""
        self.daily_start_value = current_value

    def reset(self) -> None:
        """Reset halt state (manual override)."""
        self.halted = False
        self.halt_reason = ""
        logger.info("Risk manager reset — trading resumed")

    def _halt(self, reason: str) -> None:
        self.halted = True
        self.halt_reason = reason
        logger.error(f"CIRCUIT BREAKER: {reason}")
