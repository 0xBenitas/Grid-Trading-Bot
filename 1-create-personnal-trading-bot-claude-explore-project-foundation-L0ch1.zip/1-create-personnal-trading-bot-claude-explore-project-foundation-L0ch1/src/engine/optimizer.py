"""Grid Bot Parameter Optimizer.

Brute-force parameter sweep across key grid bot settings to find
the most stable, profitable configuration for a given pair and period.

Evaluates combinations of:
- num_grids: number of grid levels
- atr_multiplier: grid range width
- spacing: arithmetic vs geometric
- regime_filter: on/off
- rsi_filter: on/off

Ranks results by a stability score that balances ROI, drawdown, and consistency.
"""

import itertools
from copy import deepcopy
from dataclasses import dataclass, field

import pandas as pd
from loguru import logger

from src.core.models import GridConfig, BacktestResult
from src.engine.backtester import GridBacktester


@dataclass
class OptimizationResult:
    """Result of a single parameter combination."""
    params: dict
    roi_pct: float
    annualized_roi_pct: float
    max_drawdown_pct: float
    completed_cycles: int
    avg_profit_per_cycle: float
    uptime_pct: float
    vs_hold_pct: float
    stability_score: float  # composite score for ranking


@dataclass
class OptimizationReport:
    """Full optimization report."""
    symbol: str
    period: str
    total_combinations: int
    results: list[OptimizationResult] = field(default_factory=list)

    @property
    def best(self) -> OptimizationResult | None:
        if not self.results:
            return None
        return self.results[0]


# Default parameter search space
DEFAULT_SEARCH_SPACE = {
    "num_grids": [15, 20, 30, 40],
    "atr_multiplier": [1.5, 2.0, 2.5, 3.0],
    "spacing": ["geometric", "arithmetic"],
    "regime_filter": [True, False],
    "rsi_filter": [True, False],
}

# Minimal search space for quick runs
QUICK_SEARCH_SPACE = {
    "num_grids": [20, 30],
    "atr_multiplier": [2.0, 2.5],
    "spacing": ["geometric"],
    "regime_filter": [True],
    "rsi_filter": [True, False],
}


def calculate_stability_score(result: BacktestResult) -> float:
    """Calculate a composite stability score.

    Weights:
    - 40% ROI (annualized, capped at 100% to avoid overfitting to outliers)
    - 30% Low drawdown (inverted — lower drawdown = higher score)
    - 20% Number of completed cycles (more cycles = more consistent)
    - 10% vs buy & hold (positive = strategy adds value)

    Score is 0-100 scale.
    """
    # ROI component (0-40 points)
    roi_capped = min(result.annualized_roi_pct, 100)
    roi_score = max(0, roi_capped) * 0.4

    # Drawdown component (0-30 points)
    # Perfect = 0% drawdown = 30 pts, 15% drawdown = 0 pts
    dd_abs = abs(result.max_drawdown_pct)
    dd_score = max(0, (15 - dd_abs) / 15) * 30

    # Consistency component (0-20 points)
    # More cycles = more consistent. Cap at 100 cycles for normalization.
    cycle_score = min(result.completed_cycles, 100) / 100 * 20

    # vs Hold component (0-10 points)
    vs_hold = max(0, min(result.vs_hold_pct, 50))
    vs_hold_score = vs_hold / 50 * 10

    return round(roi_score + dd_score + cycle_score + vs_hold_score, 2)


def optimize(
    df: pd.DataFrame,
    base_config: GridConfig,
    search_space: dict | None = None,
    fee_rate: float = 0.001,
    top_n: int = 10,
) -> OptimizationReport:
    """Run parameter optimization on historical data.

    Args:
        df: OHLCV DataFrame with datetime index.
        base_config: Base grid config (symbol, investment, etc.).
        search_space: Dict of param_name -> list of values to try.
        fee_rate: Trading fee rate.
        top_n: Number of top results to keep.

    Returns:
        OptimizationReport with ranked results.
    """
    if search_space is None:
        search_space = DEFAULT_SEARCH_SPACE

    # Generate all parameter combinations
    param_names = list(search_space.keys())
    param_values = list(search_space.values())
    combinations = list(itertools.product(*param_values))
    total = len(combinations)

    logger.info(f"Optimizer: testing {total} parameter combinations")

    results: list[OptimizationResult] = []

    for i, combo in enumerate(combinations):
        params = dict(zip(param_names, combo))

        # Create config with this combo's parameters
        config = deepcopy(base_config)
        for key, value in params.items():
            if hasattr(config, key):
                setattr(config, key, value)

        try:
            backtester = GridBacktester(config, fee_rate=fee_rate)
            bt_result = backtester.run(df)

            score = calculate_stability_score(bt_result)

            opt_result = OptimizationResult(
                params=params,
                roi_pct=bt_result.roi_pct,
                annualized_roi_pct=bt_result.annualized_roi_pct,
                max_drawdown_pct=bt_result.max_drawdown_pct,
                completed_cycles=bt_result.completed_cycles,
                avg_profit_per_cycle=bt_result.avg_profit_per_cycle,
                uptime_pct=bt_result.uptime_pct,
                vs_hold_pct=bt_result.vs_hold_pct,
                stability_score=score,
            )
            results.append(opt_result)

            if (i + 1) % 10 == 0 or (i + 1) == total:
                logger.info(f"  [{i+1}/{total}] score={score:.1f} roi={bt_result.roi_pct:.1f}% dd={bt_result.max_drawdown_pct:.1f}%")

        except Exception as e:
            logger.debug(f"  [{i+1}/{total}] FAILED: {e}")
            continue

    # Sort by stability score (highest first)
    results.sort(key=lambda r: r.stability_score, reverse=True)
    results = results[:top_n]

    period = f"{df.index[0].strftime('%Y-%m-%d')} to {df.index[-1].strftime('%Y-%m-%d')}"

    report = OptimizationReport(
        symbol=base_config.symbol,
        period=period,
        total_combinations=total,
        results=results,
    )

    if report.best:
        logger.info(
            f"Best config: score={report.best.stability_score} "
            f"roi={report.best.roi_pct}% dd={report.best.max_drawdown_pct}% "
            f"cycles={report.best.completed_cycles} params={report.best.params}"
        )

    return report


def format_report(report: OptimizationReport) -> str:
    """Format optimization report for display."""
    lines = [
        f"\n{'='*70}",
        f"  OPTIMIZATION REPORT — {report.symbol}",
        f"  Period: {report.period}",
        f"  Tested: {report.total_combinations} combinations",
        f"{'='*70}",
    ]

    for i, r in enumerate(report.results):
        lines.append(f"\n  #{i+1} — Score: {r.stability_score}")
        lines.append(f"  {'─'*40}")
        lines.append(f"  ROI: {r.roi_pct:.1f}%  (annualized: {r.annualized_roi_pct:.1f}%)")
        lines.append(f"  Max Drawdown: {r.max_drawdown_pct:.1f}%")
        lines.append(f"  Cycles: {r.completed_cycles}  (avg profit: {r.avg_profit_per_cycle:.4f})")
        lines.append(f"  vs Buy&Hold: {r.vs_hold_pct:+.1f}%")
        lines.append(f"  Uptime: {r.uptime_pct:.0f}%")
        lines.append(f"  Params: {r.params}")

    lines.append(f"\n{'='*70}")

    if report.best:
        lines.append(f"  RECOMMENDED CONFIG:")
        for k, v in report.best.params.items():
            lines.append(f"    {k}: {v}")
        lines.append(f"{'='*70}\n")

    return "\n".join(lines)
