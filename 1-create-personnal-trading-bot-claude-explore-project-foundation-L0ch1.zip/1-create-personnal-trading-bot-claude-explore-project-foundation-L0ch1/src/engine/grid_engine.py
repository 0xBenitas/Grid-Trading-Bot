"""Grid Bot Engine.

Core logic for the grid trading strategy:
1. Divide a price range into N levels (geometric spacing = equal % per level)
2. Place buy orders at levels below current price
3. Place sell orders at levels above current price
4. When a buy fills → place a sell one level up
5. When a sell fills → place a buy one level down
6. Each buy-sell cycle captures the grid spacing as profit

Optimizations:
- Geometric spacing: equal % profit per level (critical for crypto)
- Weighted quantities: buy more at lower levels (DCA effect)
- RSI filter: skip buys during crashes (falling knife protection)
- Rebalance cooldown: avoid whipsaw rebalances
- Trailing grid shift: ratchet grid upward as profits accumulate
"""

from datetime import datetime
from loguru import logger

from src.core.enums import Side, OrderStatus, GridState, MarketRegime
from src.core.models import GridLevel, GridOrder, GridConfig, GridSnapshot
from src.core.utils import calculate_grid_levels, calculate_quantity_per_grid, calculate_weighted_quantities


class GridEngine:
    """Manages grid state, tracks fills, captures profit."""

    def __init__(self, config: GridConfig):
        self.config = config
        self.state = GridState.STOPPED

        # Grid levels (set by initialize())
        self.levels: list[float] = []
        self.buy_levels: dict[float, GridLevel] = {}   # price -> GridLevel
        self.sell_levels: dict[float, GridLevel] = {}   # price -> GridLevel
        self.quantity_per_grid: float = 0.0
        self.weighted_quantities: dict[float, float] = {}  # per-level quantities

        # Tracking
        self.completed_orders: list[GridOrder] = []
        self.total_profit: float = 0.0
        self.total_fees: float = 0.0
        self.coin_held: float = 0.0
        self.fiat_held: float = 0.0
        self.initial_investment: float = 0.0

        # Regime
        self.current_regime: MarketRegime = MarketRegime.UNKNOWN
        self.current_chop: float = 0.0
        self.current_atr: float = 0.0
        self.current_rsi: float = 50.0

        # Rebalance cooldown
        self._candles_since_rebalance: int = 999  # start high so first rebalance is allowed
        self._last_shift_profit: float = 0.0  # profit level at last trailing shift

    def initialize(self, current_price: float, lower: float = 0, upper: float = 0) -> None:
        """Set up the grid around the current price."""
        if lower <= 0 or upper <= 0:
            lower = self.config.lower_price
            upper = self.config.upper_price

        if lower <= 0 or upper <= 0:
            raise ValueError("Grid bounds must be set (or use ATR auto-calculation)")

        if lower >= upper:
            raise ValueError(f"lower_price ({lower}) must be < upper_price ({upper})")

        if current_price < lower or current_price > upper:
            logger.warning(f"Current price {current_price} outside grid [{lower}, {upper}]")

        # Use configured spacing (geometric by default)
        self.levels = calculate_grid_levels(
            lower, upper, self.config.num_grids,
            spacing=self.config.spacing,
        )

        # Calculate base quantity (used as fallback)
        self.quantity_per_grid = calculate_quantity_per_grid(
            self.config.total_investment,
            self.config.num_grids,
            current_price,
        )

        # Calculate weighted quantities if enabled
        if self.config.weighted_qty:
            self.weighted_quantities = calculate_weighted_quantities(
                self.config.total_investment,
                self.levels,
                current_price,
            )

        self.initial_investment = self.config.total_investment
        self.fiat_held = self.config.total_investment
        self.coin_held = 0.0

        # Place initial orders: buys below price
        self.buy_levels.clear()
        self.sell_levels.clear()

        for level in self.levels:
            if level < current_price:
                qty = self._qty_for_level(level)
                self.buy_levels[level] = GridLevel(
                    price=level,
                    side=Side.BUY,
                    quantity=qty,
                )

        self.state = GridState.RUNNING
        self._candles_since_rebalance = 999  # allow immediate action after init
        self._last_shift_profit = 0.0
        logger.info(
            f"Grid initialized: {len(self.levels)} levels "
            f"[{lower:.2f} - {upper:.2f}], "
            f"{len(self.buy_levels)} buy orders, "
            f"spacing={self.config.spacing}, "
            f"weighted={self.config.weighted_qty}"
        )

    def _qty_for_level(self, price: float) -> float:
        """Get quantity for a specific price level."""
        if self.config.weighted_qty and price in self.weighted_quantities:
            return self.weighted_quantities[price]
        return self.quantity_per_grid

    def update(
        self,
        current_price: float,
        low: float,
        high: float,
        timestamp: datetime,
        fee_rate: float = 0.001,
    ) -> list[GridOrder]:
        """Process a new candle / price update.

        Checks if any grid levels were hit by the candle's range [low, high].
        Returns list of completed buy-sell cycles.
        """
        if self.state != GridState.RUNNING:
            return []

        self._candles_since_rebalance += 1
        new_completions = []

        # RSI filter: skip buys during extreme oversold (falling knife)
        rsi_blocks_buy = (
            self.config.rsi_filter
            and self.current_rsi < self.config.rsi_oversold
        )

        # Check buy fills (price went down to buy level)
        filled_buys = []
        for price, level in sorted(self.buy_levels.items()):
            if low <= price and level.status == OrderStatus.PENDING:
                # RSI filter: don't catch falling knives
                if rsi_blocks_buy:
                    continue

                qty = level.quantity
                cost = price * qty
                fee = cost * fee_rate
                if self.fiat_held >= cost + fee:
                    level.status = OrderStatus.FILLED
                    level.filled_at = timestamp
                    level.fee = fee
                    self.fiat_held -= (cost + fee)
                    self.coin_held += qty
                    self.total_fees += fee
                    filled_buys.append(price)

                    # Place a sell order one level up
                    level_idx = self.levels.index(price)
                    if level_idx + 1 < len(self.levels):
                        sell_price = self.levels[level_idx + 1]
                        if sell_price not in self.sell_levels:
                            self.sell_levels[sell_price] = GridLevel(
                                price=sell_price,
                                side=Side.SELL,
                                quantity=qty,
                            )

        # Check sell fills (price went up to sell level)
        filled_sells = []
        for price, level in sorted(self.sell_levels.items()):
            if high >= price and level.status == OrderStatus.PENDING:
                qty = level.quantity
                if self.coin_held >= qty * 0.999:  # small tolerance
                    revenue = price * qty
                    fee = revenue * fee_rate
                    level.status = OrderStatus.FILLED
                    level.filled_at = timestamp
                    level.quantity = qty
                    level.fee = fee
                    self.fiat_held += (revenue - fee)
                    self.coin_held -= qty
                    self.total_fees += fee
                    filled_sells.append(price)

                    # Find the matching buy (one level down)
                    level_idx = self.levels.index(price)
                    if level_idx - 1 >= 0:
                        buy_price = self.levels[level_idx - 1]
                        buy_level = self.buy_levels.get(buy_price)
                        if buy_level and buy_level.status == OrderStatus.FILLED:
                            order = GridOrder(
                                buy_price=buy_price,
                                sell_price=price,
                                quantity=qty,
                                buy_time=buy_level.filled_at,
                                sell_time=timestamp,
                                buy_fee=buy_level.fee,
                                sell_fee=fee,
                            )
                            self.completed_orders.append(order)
                            self.total_profit += order.net_profit
                            new_completions.append(order)

                            # Reset the buy level for reuse
                            buy_level.status = OrderStatus.PENDING
                            buy_level.filled_at = None

                    # Remove the sell level
                    del self.sell_levels[price]

        # Re-place buy orders at sold levels
        for sell_price in filled_sells:
            level_idx = self.levels.index(sell_price)
            if level_idx - 1 >= 0:
                buy_price = self.levels[level_idx - 1]
                if buy_price in self.buy_levels:
                    self.buy_levels[buy_price].status = OrderStatus.PENDING

        # Trailing grid shift: move grid up when profits exceed threshold
        if self.config.trailing_shift and new_completions:
            self._check_trailing_shift(current_price)

        return new_completions

    def _check_trailing_shift(self, current_price: float) -> None:
        """Shift grid upward when accumulated profit exceeds threshold.

        This "ratchets" the grid up, locking in gains and placing new
        buy orders at higher levels (closer to the new price floor).
        """
        profit_since_shift = self.total_profit - self._last_shift_profit
        threshold = self.initial_investment * self.config.trailing_shift_pct

        if profit_since_shift >= threshold and self.levels:
            grid_spacing = self.levels[1] - self.levels[0] if len(self.levels) > 1 else 0
            if grid_spacing <= 0:
                return

            # Shift all levels up by one grid spacing
            old_lower = self.levels[0]
            new_lower = old_lower + grid_spacing
            new_upper = self.levels[-1] + grid_spacing

            # Only shift if current price is in the upper half of the grid
            mid = (self.levels[0] + self.levels[-1]) / 2
            if current_price <= mid:
                return

            self.levels = calculate_grid_levels(
                new_lower, new_upper, self.config.num_grids,
                spacing=self.config.spacing,
            )

            # Rebuild buy/sell levels
            old_buys = dict(self.buy_levels)
            old_sells = dict(self.sell_levels)
            self.buy_levels.clear()
            self.sell_levels.clear()

            for level in self.levels:
                if level < current_price:
                    qty = self._qty_for_level(level)
                    self.buy_levels[level] = GridLevel(
                        price=level, side=Side.BUY, quantity=qty,
                    )

            self._last_shift_profit = self.total_profit
            logger.info(f"Grid shifted up: [{new_lower:.2f} - {new_upper:.2f}]")

    def update_regime(self, choppiness: float, atr: float) -> None:
        """Update market regime based on choppiness index."""
        self.current_chop = choppiness
        self.current_atr = atr

        if choppiness > self.config.chop_threshold:
            self.current_regime = MarketRegime.RANGING
            if self.state == GridState.PAUSED:
                self.state = GridState.RUNNING
                logger.info(f"Grid RESUMED — market ranging (chop={choppiness:.1f})")
        else:
            self.current_regime = MarketRegime.TRENDING
            if self.config.regime_filter and self.state == GridState.RUNNING:
                self.state = GridState.PAUSED
                logger.info(f"Grid PAUSED — market trending (chop={choppiness:.1f})")

    def update_rsi(self, rsi: float) -> None:
        """Update current RSI for the anti-crash filter."""
        self.current_rsi = rsi

    def rebalance(self, current_price: float) -> None:
        """Reposition the grid when price breaks out of the range.

        Includes cooldown to avoid whipsaw rebalances.
        """
        if not self.config.rebalance_on_breakout:
            return

        if not self.levels:
            return

        lower = self.levels[0]
        upper = self.levels[-1]

        if lower <= current_price <= upper:
            return

        # Cooldown: don't rebalance too frequently
        if self._candles_since_rebalance < self.config.rebalance_cooldown:
            return

        logger.info(f"Price {current_price:.2f} broke out of [{lower:.2f}, {upper:.2f}] — rebalancing grid")

        # Calculate new range
        if self.config.use_atr_spacing and self.current_atr > 0:
            half_range = self.current_atr * self.config.atr_multiplier
            new_lower = current_price - half_range
            new_upper = current_price + half_range
        else:
            width = upper - lower
            new_lower = current_price - width / 2
            new_upper = current_price + width / 2

        new_lower = max(new_lower, current_price * 0.5)

        # Liquidate coins at current price before rebalancing
        if self.coin_held > 0:
            self.fiat_held += self.coin_held * current_price
            self.coin_held = 0.0

        # Re-initialize with updated investment
        self.config.total_investment = self.fiat_held
        self._candles_since_rebalance = 0
        self.initialize(current_price, new_lower, new_upper)

    def get_snapshot(self, current_price: float, timestamp: datetime) -> GridSnapshot:
        """Get current state for monitoring/dashboard."""
        active_buys = sum(1 for l in self.buy_levels.values() if l.status == OrderStatus.PENDING)
        active_sells = sum(1 for l in self.sell_levels.values() if l.status == OrderStatus.PENDING)

        unrealized = self.coin_held * current_price
        total_value = self.fiat_held + unrealized
        roi = ((total_value - self.initial_investment) / self.initial_investment * 100
               if self.initial_investment > 0 else 0)

        return GridSnapshot(
            timestamp=timestamp,
            state=self.state.value,
            current_price=current_price,
            lower_price=self.levels[0] if self.levels else 0,
            upper_price=self.levels[-1] if self.levels else 0,
            num_grids=len(self.levels),
            active_buy_orders=active_buys,
            active_sell_orders=active_sells,
            filled_cycles=len(self.completed_orders),
            total_profit=round(self.total_profit, 4),
            total_fees=round(self.total_fees, 4),
            investment=self.initial_investment,
            coin_held=round(self.coin_held, 8),
            fiat_held=round(self.fiat_held, 4),
            unrealized_pnl=round(unrealized - (self.initial_investment - self.fiat_held), 4),
            market_regime=self.current_regime.value,
            choppiness=round(self.current_chop, 2),
            atr=round(self.current_atr, 2),
            roi_pct=round(roi, 4),
        )

    @property
    def total_value_at(self) -> float:
        return self.fiat_held

    def value_at_price(self, price: float) -> float:
        """Total portfolio value at a given price."""
        return self.fiat_held + self.coin_held * price
