"""Strategy module — currently grid bot only."""
