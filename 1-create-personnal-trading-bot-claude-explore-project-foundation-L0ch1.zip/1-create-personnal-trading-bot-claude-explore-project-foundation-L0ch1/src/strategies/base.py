"""Base strategy interface — kept for future expansion beyond grid."""

from abc import ABC, abstractmethod
import pandas as pd


class BaseStrategy(ABC):
    """Base class for non-grid strategies (future use)."""

    def __init__(self, config: dict):
        self.config = config

    @abstractmethod
    def compute_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        pass

    @abstractmethod
    def should_enter(self, df: pd.DataFrame, index: int) -> bool:
        pass

    @abstractmethod
    def should_exit(self, df: pd.DataFrame, index: int) -> bool:
        pass
