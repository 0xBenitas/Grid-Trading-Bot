import math

import numpy as np
import pandas as pd


def truncate(n: float, decimals: int = 0) -> str:
    """Floor a number to N decimal places. Used for order sizing."""
    r = math.floor(float(n) * 10**decimals) / 10**decimals
    return str(r)


def get_chop(high: pd.Series, low: pd.Series, close: pd.Series, window: int) -> pd.Series:
    """Choppiness Index — measures if market is trending or ranging.

    > 50 = choppy/ranging (GOOD for grid bot)
    < 50 = trending (BAD for grid bot, risk of breakout)
    """
    tr1 = pd.DataFrame(high - low).rename(columns={0: "tr1"})
    tr2 = pd.DataFrame(abs(high - close.shift(1))).rename(columns={0: "tr2"})
    tr3 = pd.DataFrame(abs(low - close.shift(1))).rename(columns={0: "tr3"})
    frames = [tr1, tr2, tr3]
    tr = pd.concat(frames, axis=1, join="inner").dropna().max(axis=1)
    atr = tr.rolling(1).mean()
    highh = high.rolling(window).max()
    lowl = low.rolling(window).min()
    ci = 100 * np.log10((atr.rolling(window).sum()) / (highh - lowl)) / np.log10(window)
    return ci


def calculate_grid_levels(
    lower: float,
    upper: float,
    num_grids: int,
    spacing: str = "arithmetic",
) -> list[float]:
    """Calculate grid price levels.

    Args:
        lower: Lower price bound.
        upper: Upper price bound.
        num_grids: Number of grid lines.
        spacing: 'arithmetic' (equal $ spacing) or 'geometric' (equal % spacing).

    Returns:
        Sorted list of price levels from lower to upper.
    """
    if spacing == "geometric":
        log_lower = np.log(lower)
        log_upper = np.log(upper)
        levels = np.exp(np.linspace(log_lower, log_upper, num_grids + 1))
    else:
        levels = np.linspace(lower, upper, num_grids + 1)

    return sorted([round(p, 2) for p in levels])


def calculate_quantity_per_grid(
    total_investment: float,
    num_grids: int,
    reference_price: float,
    fee_rate: float = 0.001,
) -> float:
    """Calculate quantity to allocate per grid level.

    Splits total investment equally across grid levels, accounting for fees.
    """
    investment_per_grid = total_investment / num_grids
    quantity = investment_per_grid / reference_price
    # Reserve for fees
    quantity *= (1 - fee_rate)
    return quantity


def calculate_weighted_quantities(
    total_investment: float,
    levels: list[float],
    current_price: float,
    fee_rate: float = 0.001,
) -> dict[float, float]:
    """Calculate weighted quantities — buy more at lower levels (DCA effect).

    Lower levels get more capital allocation, so when price drops further,
    the bot accumulates more coins cheaply. When price bounces, the profit
    from these larger positions is bigger.

    Returns:
        Dict mapping each buy level price -> quantity to buy.
    """
    buy_levels = [l for l in levels if l < current_price]
    if not buy_levels:
        # Fallback: equal allocation
        qty = (total_investment / max(len(levels), 1)) / current_price * (1 - fee_rate)
        return {l: qty for l in levels}

    # Weight: lower price = higher weight (inverse price weighting)
    max_price = max(buy_levels)
    weights = {}
    for price in buy_levels:
        # Weight inversely proportional to price (lower = more weight)
        weights[price] = max_price / price

    total_weight = sum(weights.values())

    # Allocate investment proportionally to weights
    # Use half the investment for buys (other half stays as reserve for sells/rebalance)
    buy_budget = total_investment * 0.8
    quantities = {}
    for price, weight in weights.items():
        allocation = buy_budget * (weight / total_weight)
        quantities[price] = (allocation / price) * (1 - fee_rate)

    return quantities
