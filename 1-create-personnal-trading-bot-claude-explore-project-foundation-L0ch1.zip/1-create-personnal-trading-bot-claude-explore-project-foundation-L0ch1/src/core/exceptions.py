class TradingBotError(Exception):
    """Base exception."""


class InsufficientBalanceError(TradingBotError):
    """Not enough balance to place order."""


class OrderFailedError(TradingBotError):
    """Order execution failed on exchange."""


class DataFetchError(TradingBotError):
    """Failed to fetch market data."""


class ConfigError(TradingBotError):
    """Invalid or missing configuration."""


class GridError(TradingBotError):
    """Grid bot specific error."""


class CircuitBreakerError(TradingBotError):
    """Risk limit breached, trading halted."""
