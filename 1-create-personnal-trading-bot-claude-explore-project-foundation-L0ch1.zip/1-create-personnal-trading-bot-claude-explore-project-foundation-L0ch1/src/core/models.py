from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

from src.core.enums import Side, OrderStatus


@dataclass
class GridLevel:
    """A single level in the grid."""
    price: float
    side: Side
    status: OrderStatus = OrderStatus.PENDING
    filled_at: Optional[datetime] = None
    quantity: float = 0.0
    fee: float = 0.0


@dataclass
class GridOrder:
    """A completed buy-sell cycle on the grid."""
    buy_price: float
    sell_price: float
    quantity: float
    buy_time: datetime
    sell_time: datetime
    buy_fee: float = 0.0
    sell_fee: float = 0.0

    @property
    def gross_profit(self) -> float:
        return (self.sell_price - self.buy_price) * self.quantity

    @property
    def net_profit(self) -> float:
        return self.gross_profit - self.buy_fee - self.sell_fee

    @property
    def return_pct(self) -> float:
        cost = self.buy_price * self.quantity + self.buy_fee
        if cost == 0:
            return 0.0
        return (self.net_profit / cost) * 100


@dataclass
class GridConfig:
    """Configuration for a grid bot instance."""
    symbol: str = "BTCUSDT"
    lower_price: float = 0.0       # auto-calculated if 0
    upper_price: float = 0.0       # auto-calculated if 0
    num_grids: int = 20
    total_investment: float = 1000.0
    use_atr_spacing: bool = True    # dynamic spacing based on ATR
    atr_period: int = 14
    atr_multiplier: float = 2.0     # grid range = price +/- ATR * multiplier
    regime_filter: bool = True      # pause in trending markets
    chop_period: int = 14
    chop_threshold: float = 50.0    # chop > threshold = ranging (good)
    max_open_orders: int = 20
    rebalance_on_breakout: bool = True  # reposition grid on range breakout
    # --- Optimization settings ---
    spacing: str = "geometric"          # "geometric" (equal %) or "arithmetic" (equal $)
    weighted_qty: bool = True           # buy more at lower levels (DCA effect)
    rsi_filter: bool = True             # skip buys when RSI < oversold (falling knife)
    rsi_period: int = 14
    rsi_oversold: float = 25.0          # don't buy below this RSI (crash zone)
    rsi_overbought: float = 75.0        # don't sell above this (let it run)
    rebalance_cooldown: int = 6         # min candles between rebalances
    trailing_shift: bool = True         # shift grid up as profits accumulate
    trailing_shift_pct: float = 0.02    # shift when profit > 2% of investment


@dataclass
class GridSnapshot:
    """Current state of the grid bot for monitoring."""
    timestamp: datetime
    state: str
    current_price: float
    lower_price: float
    upper_price: float
    num_grids: int
    active_buy_orders: int
    active_sell_orders: int
    filled_cycles: int
    total_profit: float
    total_fees: float
    investment: float
    coin_held: float
    fiat_held: float
    unrealized_pnl: float
    market_regime: str
    choppiness: float
    atr: float
    roi_pct: float


@dataclass
class BacktestResult:
    """Results from a grid bot backtest."""
    # Performance
    initial_investment: float
    final_value: float
    total_profit: float
    total_fees: float
    roi_pct: float
    annualized_roi_pct: float
    buy_hold_roi_pct: float
    vs_hold_pct: float

    # Grid stats
    completed_cycles: int
    total_buy_fills: int
    total_sell_fills: int
    avg_profit_per_cycle: float
    avg_profit_pct_per_cycle: float

    # Risk
    max_drawdown_pct: float
    max_coin_exposure_pct: float
    max_unrealized_loss: float

    # Time
    start_date: datetime
    end_date: datetime
    duration_days: float
    uptime_pct: float  # % of time grid was active (not paused by regime filter)

    # Data
    completed_orders: list[GridOrder] = field(default_factory=list)
    equity_curve: list[float] = field(default_factory=list)
    equity_dates: list[datetime] = field(default_factory=list)
    snapshots: list[GridSnapshot] = field(default_factory=list)
