from enum import Enum


class Side(str, Enum):
    BUY = "buy"
    SELL = "sell"


class OrderType(str, Enum):
    MARKET = "market"
    LIMIT = "limit"


class OrderStatus(str, Enum):
    PENDING = "pending"
    FILLED = "filled"
    CANCELLED = "cancelled"
    PARTIAL = "partial"


class GridState(str, Enum):
    RUNNING = "running"
    PAUSED = "paused"      # paused by regime filter
    STOPPED = "stopped"    # manually stopped or circuit breaker


class MarketRegime(str, Enum):
    TRENDING = "trending"
    RANGING = "ranging"
    UNKNOWN = "unknown"
