"""Abstract exchange client interface."""

from abc import ABC, abstractmethod

import pandas as pd

from src.core.enums import Side, OrderType


class ExchangeClient(ABC):
    """Base class for exchange implementations."""

    @abstractmethod
    def get_balance(self, asset: str) -> float:
        """Get the available balance for a given asset."""

    @abstractmethod
    def place_order(
        self,
        symbol: str,
        side: Side,
        order_type: OrderType,
        quantity: float,
        price: float | None = None,
    ) -> dict:
        """Place an order on the exchange."""

    @abstractmethod
    def get_klines(
        self,
        symbol: str,
        interval: str,
        limit: int = 500,
    ) -> pd.DataFrame:
        """Fetch recent kline/candlestick data."""
