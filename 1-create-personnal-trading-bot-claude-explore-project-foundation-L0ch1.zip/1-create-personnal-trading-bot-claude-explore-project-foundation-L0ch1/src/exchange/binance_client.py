"""Binance exchange client implementation.

Migrated from live-ftx.py, adapted for Binance API.
"""

import pandas as pd
from binance.client import Client
from loguru import logger

from src.core.enums import Side, OrderType
from src.core.exceptions import OrderFailedError
from src.core.utils import truncate
from src.exchange.base import ExchangeClient


class BinanceExchangeClient(ExchangeClient):
    """Binance exchange client wrapping python-binance."""

    def __init__(self, api_key: str, api_secret: str, testnet: bool = False):
        self.client = Client(api_key=api_key, api_secret=api_secret, testnet=testnet)
        logger.info(f"Binance client initialized (testnet={testnet})")

    def get_balance(self, asset: str) -> float:
        """Get available balance for an asset.

        Migrated from getBalance() in live-ftx.py.
        """
        try:
            balance = self.client.get_asset_balance(asset=asset)
            if balance is None:
                return 0.0
            return float(balance["free"])
        except Exception as e:
            logger.error(f"Failed to get balance for {asset}: {e}")
            return 0.0

    def place_order(
        self,
        symbol: str,
        side: Side,
        order_type: OrderType,
        quantity: float,
        price: float | None = None,
    ) -> dict:
        """Place an order on Binance."""
        try:
            if order_type == OrderType.MARKET:
                if side == Side.BUY:
                    order = self.client.order_market_buy(symbol=symbol, quantity=quantity)
                else:
                    order = self.client.order_market_sell(symbol=symbol, quantity=quantity)
            else:
                if price is None:
                    raise OrderFailedError("Price required for limit orders")
                if side == Side.BUY:
                    order = self.client.order_limit_buy(symbol=symbol, quantity=quantity, price=str(price))
                else:
                    order = self.client.order_limit_sell(symbol=symbol, quantity=quantity, price=str(price))

            logger.info(f"Order placed: {side.value} {quantity} {symbol} ({order_type.value})")
            return order

        except Exception as e:
            raise OrderFailedError(f"Order failed: {e}") from e

    def get_klines(self, symbol: str, interval: str, limit: int = 500) -> pd.DataFrame:
        """Fetch recent kline data from Binance."""
        klines = self.client.get_klines(symbol=symbol, interval=interval, limit=limit)
        columns = [
            "timestamp", "open", "high", "low", "close", "volume",
            "close_time", "quote_av", "trades", "tb_base_av", "tb_quote_av", "ignore",
        ]
        df = pd.DataFrame(klines, columns=columns)
        df = df[["timestamp", "open", "high", "low", "close", "volume"]].copy()
        for col in ["open", "high", "low", "close", "volume"]:
            df[col] = pd.to_numeric(df[col])
        df = df.set_index("timestamp")
        df.index = pd.to_datetime(df.index, unit="ms")
        df.index.name = "timestamp"
        return df
