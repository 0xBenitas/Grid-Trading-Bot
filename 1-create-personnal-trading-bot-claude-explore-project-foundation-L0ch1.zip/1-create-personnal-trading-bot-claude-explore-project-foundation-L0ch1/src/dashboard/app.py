"""Grid Bot Dashboard — Dash/Plotly."""

from dash import Dash, html, dcc, Input, Output, State, callback_context
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def create_app(config: dict) -> Dash:
    app = Dash(__name__, suppress_callback_exceptions=True, title="Grid Bot")

    app.layout = html.Div([
        # Header
        html.Div([
            html.H1("Grid Trading Bot", style={"margin": "0", "fontSize": "24px"}),
            html.P("Backtest & Monitor", style={"margin": "0", "color": "#888"}),
        ], style={"padding": "20px 30px", "borderBottom": "1px solid #333", "backgroundColor": "#1a1a2e"}),

        # Controls
        html.Div([
            html.Div([
                html.Label("Symbol", style={"fontSize": "12px", "color": "#888"}),
                dcc.Dropdown(
                    id="symbol",
                    options=[
                        {"label": "BTC/USDT", "value": "BTCUSDT"},
                        {"label": "ETH/USDT", "value": "ETHUSDT"},
                        {"label": "SOL/USDT", "value": "SOLUSDT"},
                        {"label": "BNB/USDT", "value": "BNBUSDT"},
                    ],
                    value="ETHUSDT",
                    style={"color": "#000"},
                ),
            ], style={"flex": "1", "minWidth": "140px"}),
            html.Div([
                html.Label("Start Date", style={"fontSize": "12px", "color": "#888"}),
                dcc.Input(id="start-date", type="text", value="01 January 2024",
                          style=_input_style()),
            ], style={"flex": "1", "minWidth": "160px"}),
            html.Div([
                html.Label("Grid Lines", style={"fontSize": "12px", "color": "#888"}),
                dcc.Input(id="num-grids", type="number", value=20, min=5, max=100,
                          style=_input_style()),
            ], style={"flex": "0.6", "minWidth": "100px"}),
            html.Div([
                html.Label("Investment (USDT)", style={"fontSize": "12px", "color": "#888"}),
                dcc.Input(id="investment", type="number", value=1000, min=100,
                          style=_input_style()),
            ], style={"flex": "0.8", "minWidth": "130px"}),
            html.Div([
                html.Label("ATR Mult.", style={"fontSize": "12px", "color": "#888"}),
                dcc.Input(id="atr-mult", type="number", value=2.0, min=0.5, max=5, step=0.5,
                          style=_input_style()),
            ], style={"flex": "0.5", "minWidth": "90px"}),
            html.Div([
                html.Label("Spacing", style={"fontSize": "12px", "color": "#888"}),
                dcc.Dropdown(
                    id="spacing",
                    options=[
                        {"label": "Geometric (%)", "value": "geometric"},
                        {"label": "Arithmetic ($)", "value": "arithmetic"},
                    ],
                    value="geometric",
                    style={"color": "#000"},
                ),
            ], style={"flex": "0.7", "minWidth": "120px"}),
            html.Div([
                html.Label("Filters", style={"fontSize": "12px", "color": "#888"}),
                dcc.Checklist(
                    id="filters",
                    options=[
                        {"label": " Regime", "value": "regime"},
                        {"label": " RSI", "value": "rsi"},
                        {"label": " Weighted", "value": "weighted"},
                    ],
                    value=["regime", "rsi", "weighted"],
                    style={"marginTop": "4px", "fontSize": "12px"},
                ),
            ], style={"flex": "1", "minWidth": "160px"}),
            html.Div([
                html.Label("\u00a0", style={"fontSize": "12px"}),
                html.Button("Run Backtest", id="run-btn", n_clicks=0,
                            style=_btn_style()),
            ], style={"flex": "0.7", "minWidth": "130px"}),
        ], style={"display": "flex", "gap": "12px", "padding": "20px 30px",
                  "flexWrap": "wrap", "backgroundColor": "#16213e"}),

        # Results
        dcc.Loading(
            type="circle",
            children=html.Div(id="results", style={"padding": "20px 30px"},
                              children=html.P("Configure parameters and run a backtest.",
                                              style={"color": "#888", "textAlign": "center", "padding": "60px"})),
        ),
    ], style={
        "fontFamily": "'Segoe UI', sans-serif",
        "backgroundColor": "#0f0f23", "color": "#e0e0e0", "minHeight": "100vh",
    })

    _register_callbacks(app, config)
    return app


def _register_callbacks(app, config):
    @app.callback(
        Output("results", "children"),
        Input("run-btn", "n_clicks"),
        State("symbol", "value"),
        State("start-date", "value"),
        State("num-grids", "value"),
        State("investment", "value"),
        State("atr-mult", "value"),
        State("spacing", "value"),
        State("filters", "value"),
        prevent_initial_call=True,
    )
    def run_backtest(n_clicks, symbol, start_date, num_grids, investment, atr_mult, spacing, filters):
        if not n_clicks:
            return html.P("Click Run Backtest", style={"color": "#888"})

        filters = filters or []

        try:
            from src.core.models import GridConfig
            from src.data.fetcher import fetch_historical
            from src.engine.backtester import GridBacktester

            grid_config = GridConfig(
                symbol=symbol,
                num_grids=int(num_grids),
                total_investment=float(investment),
                atr_multiplier=float(atr_mult),
                use_atr_spacing=True,
                regime_filter="regime" in filters,
                spacing=spacing or "geometric",
                weighted_qty="weighted" in filters,
                rsi_filter="rsi" in filters,
            )

            df = fetch_historical(symbol=symbol, start_date=start_date)
            bt = GridBacktester(grid_config, fee_rate=0.001)
            result = bt.run(df)

            return html.Div([
                # Stats cards
                html.Div([
                    _card("Final Value", f"{result.final_value:,.2f} USDT",
                          "#4ecdc4" if result.roi_pct > 0 else "#ff6b6b"),
                    _card("ROI", f"{result.roi_pct:+.2f}%",
                          "#4ecdc4" if result.roi_pct > 0 else "#ff6b6b"),
                    _card("Ann. ROI", f"{result.annualized_roi_pct:+.1f}%",
                          "#4ecdc4" if result.annualized_roi_pct > 0 else "#ff6b6b"),
                    _card("Buy & Hold", f"{result.buy_hold_roi_pct:+.2f}%",
                          "#45b7d1"),
                    _card("vs Hold", f"{result.vs_hold_pct:+.2f}%",
                          "#4ecdc4" if result.vs_hold_pct > 0 else "#ff6b6b"),
                ], style={"display": "flex", "gap": "12px", "marginBottom": "15px", "flexWrap": "wrap"}),

                html.Div([
                    _card("Cycles", str(result.completed_cycles), "#45b7d1"),
                    _card("Profit", f"{result.total_profit:+.2f}", "#4ecdc4"),
                    _card("Avg/Cycle", f"{result.avg_profit_per_cycle:.4f}", "#96ceb4"),
                    _card("Max DD", f"{result.max_drawdown_pct:.1f}%", "#ff6b6b"),
                    _card("Fees", f"{result.total_fees:.2f}", "#888"),
                    _card("Uptime", f"{result.uptime_pct:.0f}%", "#45b7d1"),
                    _card("Days", f"{result.duration_days:.0f}", "#888"),
                ], style={"display": "flex", "gap": "12px", "marginBottom": "25px", "flexWrap": "wrap"}),

                # Charts
                _build_charts(df, result),
            ])

        except Exception as e:
            return html.P(f"Error: {e}", style={"color": "#ff6b6b", "padding": "20px"})


def _build_charts(df, result):
    fig = make_subplots(
        rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.04,
        row_heights=[0.45, 0.30, 0.25],
        subplot_titles=["Price & Grid Fills", "Equity Curve", "Profit per Cycle"],
    )

    # Price candlestick
    fig.add_trace(go.Candlestick(
        x=df.index, open=df["open"], high=df["high"], low=df["low"], close=df["close"],
        name="Price", increasing_line_color="#4ecdc4", decreasing_line_color="#ff6b6b",
    ), row=1, col=1)

    # Buy/sell markers from completed cycles
    if result.completed_orders:
        buys_x = [o.buy_time for o in result.completed_orders]
        buys_y = [o.buy_price for o in result.completed_orders]
        sells_x = [o.sell_time for o in result.completed_orders]
        sells_y = [o.sell_price for o in result.completed_orders]

        fig.add_trace(go.Scatter(
            x=buys_x, y=buys_y, mode="markers", name="Buy",
            marker=dict(symbol="triangle-up", size=7, color="#4ecdc4"),
        ), row=1, col=1)
        fig.add_trace(go.Scatter(
            x=sells_x, y=sells_y, mode="markers", name="Sell",
            marker=dict(symbol="triangle-down", size=7, color="#ff6b6b"),
        ), row=1, col=1)

    # Equity curve
    fig.add_trace(go.Scatter(
        x=result.equity_dates, y=result.equity_curve,
        name="Equity", line=dict(color="#45b7d1", width=2),
    ), row=2, col=1)

    # Profit per cycle (bar chart)
    if result.completed_orders:
        fig.add_trace(go.Bar(
            x=[o.sell_time for o in result.completed_orders],
            y=[o.net_profit for o in result.completed_orders],
            name="Cycle Profit",
            marker_color=["#4ecdc4" if o.net_profit > 0 else "#ff6b6b" for o in result.completed_orders],
        ), row=3, col=1)

    fig.update_layout(
        template="plotly_dark", paper_bgcolor="#0f0f23", plot_bgcolor="#0f0f23",
        height=900, margin=dict(l=50, r=20, t=40, b=30),
        xaxis_rangeslider_visible=False,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    )

    return dcc.Graph(figure=fig, style={"borderRadius": "8px"})


def _card(title, value, color):
    return html.Div([
        html.P(title, style={"margin": "0", "fontSize": "11px", "color": "#888"}),
        html.H4(value, style={"margin": "4px 0 0 0", "color": color, "fontSize": "15px"}),
    ], style={
        "backgroundColor": "#1a1a2e", "borderRadius": "6px",
        "padding": "10px 14px", "border": "1px solid #333", "flex": "1", "minWidth": "100px",
    })


def _input_style():
    return {
        "width": "100%", "padding": "7px",
        "backgroundColor": "#1a1a2e", "color": "#e0e0e0",
        "border": "1px solid #333", "borderRadius": "4px",
    }


def _btn_style():
    return {
        "width": "100%", "padding": "8px 16px",
        "backgroundColor": "#0f3460", "color": "#fff",
        "border": "none", "borderRadius": "4px",
        "cursor": "pointer", "fontSize": "14px",
    }
