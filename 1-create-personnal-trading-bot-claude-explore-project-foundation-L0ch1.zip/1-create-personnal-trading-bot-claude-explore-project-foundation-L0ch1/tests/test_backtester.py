"""Tests for the Grid Bot backtester."""

import numpy as np
import pandas as pd

from src.core.models import GridConfig
from src.engine.backtester import GridBacktester


def _make_ranging_data(n: int = 500, center: float = 100, amplitude: float = 20, seed: int = 42) -> pd.DataFrame:
    """Create oscillating OHLCV data — ideal for grid bot."""
    rng = np.random.default_rng(seed)
    t = np.linspace(0, 10 * np.pi, n)
    close = center + amplitude * np.sin(t) + rng.normal(0, 2, n)
    noise = rng.uniform(1, 5, n)

    return pd.DataFrame({
        "open": close + rng.normal(0, 1, n),
        "high": close + noise,
        "low": close - noise,
        "close": close,
        "volume": rng.uniform(100, 1000, n),
    }, index=pd.date_range("2024-01-01", periods=n, freq="h"))


def _make_trending_data(n: int = 500, start: float = 100, end: float = 200, seed: int = 42) -> pd.DataFrame:
    """Create trending OHLCV data — bad for grid bot."""
    rng = np.random.default_rng(seed)
    close = np.linspace(start, end, n) + rng.normal(0, 2, n)
    noise = rng.uniform(1, 5, n)

    return pd.DataFrame({
        "open": close + rng.normal(0, 1, n),
        "high": close + noise,
        "low": close - noise,
        "close": close,
        "volume": rng.uniform(100, 1000, n),
    }, index=pd.date_range("2024-01-01", periods=n, freq="h"))


def test_backtest_ranging_market():
    """Grid bot should be profitable in a ranging market."""
    df = _make_ranging_data(n=1000, center=100, amplitude=20)
    config = GridConfig(
        symbol="TEST", num_grids=10, total_investment=1000,
        use_atr_spacing=True, atr_multiplier=2.0,
        regime_filter=False, rebalance_on_breakout=True,
        spacing="arithmetic", weighted_qty=False, rsi_filter=False, trailing_shift=False,
    )

    bt = GridBacktester(config, fee_rate=0.001)
    result = bt.run(df)

    assert result.initial_investment == 1000
    assert result.final_value > 0
    assert result.completed_cycles > 0
    assert result.total_fees > 0
    assert len(result.equity_curve) > 0
    assert result.duration_days > 0


def test_backtest_generates_profit_in_range():
    """In a clearly ranging market, grid bot should generate grid profit."""
    df = _make_ranging_data(n=2000, center=100, amplitude=15)
    config = GridConfig(
        symbol="TEST", num_grids=10, total_investment=1000,
        use_atr_spacing=True, atr_multiplier=3.0,
        regime_filter=False, rebalance_on_breakout=True,
        spacing="arithmetic", weighted_qty=False, rsi_filter=False, trailing_shift=False,
    )

    bt = GridBacktester(config, fee_rate=0.0005)  # low fees
    result = bt.run(df)

    # Grid profit should be positive (from completed buy-sell cycles)
    assert result.total_profit > 0
    assert result.completed_cycles > 5


def test_backtest_with_regime_filter():
    """Regime filter should reduce uptime in trending data."""
    df = _make_trending_data(n=500)
    config = GridConfig(
        symbol="TEST", num_grids=10, total_investment=1000,
        use_atr_spacing=True, atr_multiplier=2.0,
        regime_filter=True,
        rebalance_on_breakout=True,
        spacing="arithmetic", weighted_qty=False, rsi_filter=False, trailing_shift=False,
    )

    bt = GridBacktester(config, fee_rate=0.001)
    result = bt.run(df)

    # With regime filter, uptime should be < 100%
    assert result.uptime_pct < 100


def test_backtest_drawdown_tracked():
    df = _make_ranging_data(n=500)
    config = GridConfig(
        symbol="TEST", num_grids=10, total_investment=1000,
        use_atr_spacing=True, atr_multiplier=2.0,
        regime_filter=False, rebalance_on_breakout=True,
        spacing="arithmetic", weighted_qty=False, rsi_filter=False, trailing_shift=False,
    )

    bt = GridBacktester(config, fee_rate=0.001)
    result = bt.run(df)

    # Drawdown should be negative (or zero)
    assert result.max_drawdown_pct <= 0


def test_backtest_equity_curve_length():
    df = _make_ranging_data(n=200)
    config = GridConfig(
        symbol="TEST", num_grids=5, total_investment=1000,
        use_atr_spacing=True, atr_multiplier=2.0,
        regime_filter=False, rebalance_on_breakout=True,
        spacing="arithmetic", weighted_qty=False, rsi_filter=False, trailing_shift=False,
    )

    bt = GridBacktester(config, fee_rate=0.001)
    result = bt.run(df)

    # Equity curve should have entries for every candle after warmup
    assert len(result.equity_curve) > 100
    assert len(result.equity_curve) == len(result.equity_dates)


def test_backtest_snapshots():
    df = _make_ranging_data(n=200)
    config = GridConfig(
        symbol="TEST", num_grids=5, total_investment=1000,
        use_atr_spacing=True, atr_multiplier=2.0,
        regime_filter=False, rebalance_on_breakout=True,
        spacing="arithmetic", weighted_qty=False, rsi_filter=False, trailing_shift=False,
    )

    bt = GridBacktester(config, fee_rate=0.001, snapshot_interval=10)
    result = bt.run(df)

    assert len(result.snapshots) > 0
    snap = result.snapshots[0]
    assert snap.investment > 0
    assert snap.current_price > 0


def test_backtest_with_optimizations():
    """Backtest with all optimization features enabled."""
    df = _make_ranging_data(n=1000, center=100, amplitude=20)
    config = GridConfig(
        symbol="TEST", num_grids=10, total_investment=1000,
        use_atr_spacing=True, atr_multiplier=2.0,
        regime_filter=True, rebalance_on_breakout=True,
        spacing="geometric", weighted_qty=True,
        rsi_filter=True, trailing_shift=True,
    )

    bt = GridBacktester(config, fee_rate=0.001)
    result = bt.run(df)

    assert result.initial_investment == 1000
    assert result.final_value > 0
    assert len(result.equity_curve) > 0
