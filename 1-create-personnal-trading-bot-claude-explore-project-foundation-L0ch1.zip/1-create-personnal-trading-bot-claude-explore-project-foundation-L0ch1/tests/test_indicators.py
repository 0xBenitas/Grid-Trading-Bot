"""Tests for technical indicators."""

import numpy as np
import pandas as pd

from src.data.indicators import add_sma, add_ema, add_atr, add_choppiness, add_rsi, add_bollinger_bands


def _make_ohlcv(n: int = 100, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    close = 100 + np.cumsum(rng.normal(0, 1, n))
    return pd.DataFrame({
        "open": close - rng.uniform(0, 1, n),
        "high": close + rng.uniform(0, 2, n),
        "low": close - rng.uniform(0, 2, n),
        "close": close,
        "volume": rng.uniform(100, 1000, n),
    }, index=pd.date_range("2024-01-01", periods=n, freq="h"))


def test_add_atr():
    df = _make_ohlcv(100)
    df = add_atr(df, 14)
    assert "ATR" in df.columns
    valid = df["ATR"].dropna()
    assert len(valid) > 50
    # ATR should have some positive values (first few may be 0)
    assert (valid > 0).any()


def test_add_choppiness():
    df = _make_ohlcv(100)
    df = add_choppiness(df, 14)
    assert "CHOP" in df.columns
    valid = df["CHOP"].dropna()
    assert len(valid) > 50
    # Values should be between 0 and 100
    assert (valid >= 0).all()
    assert (valid <= 100).all()


def test_add_sma():
    df = _make_ohlcv(200)
    df = add_sma(df, 20)
    assert "SMA20" in df.columns
    expected = df["close"].iloc[:20].mean()
    assert abs(df["SMA20"].iloc[19] - expected) < 1e-6


def test_add_ema():
    df = _make_ohlcv(100)
    df = add_ema(df, 13)
    assert "EMA13" in df.columns


def test_add_rsi():
    df = _make_ohlcv(100)
    df = add_rsi(df, 14)
    valid = df["RSI"].dropna()
    assert (valid >= 0).all()
    assert (valid <= 100).all()


def test_add_bollinger():
    df = _make_ohlcv(100)
    df = add_bollinger_bands(df, 20)
    valid = df.dropna(subset=["BOL_H_BAND", "BOL_L_BAND"])
    assert (valid["BOL_H_BAND"] >= valid["BOL_L_BAND"]).all()
