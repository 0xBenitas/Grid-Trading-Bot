"""Tests for risk management."""

from src.engine.risk_manager import RiskManager, RiskConfig


def test_risk_manager_allows_normal_trading():
    rm = RiskManager(RiskConfig(max_drawdown_pct=0.15), initial_capital=1000)
    assert rm.check(current_value=1000, coin_value=200) is True


def test_risk_manager_blocks_on_drawdown():
    rm = RiskManager(RiskConfig(max_drawdown_pct=0.10), initial_capital=1000)
    # Peak at 1000, drop to 880 = 12% drawdown
    assert rm.check(current_value=880, coin_value=0) is False
    assert rm.halted is True


def test_risk_manager_blocks_overexposure():
    rm = RiskManager(RiskConfig(max_position_pct=0.50), initial_capital=1000)
    # 700 in coin out of 1000 total = 70% exposure
    assert rm.check(current_value=1000, coin_value=700) is False


def test_risk_manager_daily_loss():
    rm = RiskManager(RiskConfig(daily_loss_limit=0.05), initial_capital=1000)
    # 6% daily loss
    assert rm.check(current_value=940, coin_value=0) is False


def test_risk_manager_reset():
    rm = RiskManager(RiskConfig(max_drawdown_pct=0.10), initial_capital=1000)
    rm.check(current_value=880, coin_value=0)
    assert rm.halted is True
    rm.reset()
    assert rm.halted is False


def test_validate_order_size():
    rm = RiskManager(RiskConfig(max_single_order_pct=0.05), initial_capital=1000)
    assert rm.validate_order_size(40, 1000) is True   # 4% ok
    assert rm.validate_order_size(60, 1000) is False  # 6% too big
