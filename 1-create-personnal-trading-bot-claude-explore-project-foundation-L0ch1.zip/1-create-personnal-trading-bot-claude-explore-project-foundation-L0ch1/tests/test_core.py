"""Tests for core utilities and models."""

from src.core.utils import truncate, calculate_grid_levels, calculate_quantity_per_grid
from src.core.enums import Side, GridState, MarketRegime
from src.core.models import GridOrder


def test_truncate():
    assert truncate(3.14159, 2) == "3.14"
    assert truncate(3.999, 2) == "3.99"  # floors, not rounds
    assert truncate(0, 4) == "0.0"


def test_calculate_grid_levels_arithmetic():
    levels = calculate_grid_levels(100, 200, 10)
    assert len(levels) == 11  # 10 grids = 11 levels
    assert levels[0] == 100.0
    assert levels[-1] == 200.0
    # Equal spacing
    spacing = levels[1] - levels[0]
    for i in range(1, len(levels)):
        assert abs((levels[i] - levels[i - 1]) - spacing) < 0.01


def test_calculate_grid_levels_geometric():
    levels = calculate_grid_levels(100, 400, 4, spacing="geometric")
    assert len(levels) == 5
    assert levels[0] == 100.0
    assert abs(levels[-1] - 400.0) < 0.01
    # Geometric: equal ratio between levels
    ratios = [levels[i + 1] / levels[i] for i in range(len(levels) - 1)]
    for r in ratios:
        assert abs(r - ratios[0]) < 0.01


def test_calculate_quantity_per_grid():
    qty = calculate_quantity_per_grid(1000, 10, 100, fee_rate=0.001)
    # 1000 / 10 = 100 USDT per grid, at price 100 = 1.0, minus 0.1% fee
    assert abs(qty - 0.999) < 0.001


def test_grid_order_profit():
    order = GridOrder(
        buy_price=100, sell_price=110,
        quantity=1.0,
        buy_time=None, sell_time=None,
        buy_fee=0.1, sell_fee=0.11,
    )
    assert order.gross_profit == 10.0
    assert abs(order.net_profit - 9.79) < 0.01
    assert order.return_pct > 0


def test_enums():
    assert Side.BUY.value == "buy"
    assert GridState.RUNNING.value == "running"
    assert MarketRegime.RANGING.value == "ranging"
