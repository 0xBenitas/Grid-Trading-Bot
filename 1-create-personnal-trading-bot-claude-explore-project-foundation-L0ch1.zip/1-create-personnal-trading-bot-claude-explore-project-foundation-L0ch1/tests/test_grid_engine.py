"""Tests for the Grid Engine."""

from datetime import datetime

from src.core.enums import GridState, OrderStatus, MarketRegime
from src.core.models import GridConfig
from src.engine.grid_engine import GridEngine


def _make_config(**overrides) -> GridConfig:
    defaults = dict(
        symbol="TESTUSDT",
        num_grids=10,
        total_investment=1000,
        regime_filter=False,
        rebalance_on_breakout=False,
        # Disable optimization features for predictable legacy tests
        spacing="arithmetic",
        weighted_qty=False,
        rsi_filter=False,
        trailing_shift=False,
    )
    defaults.update(overrides)
    return GridConfig(**defaults)


def test_initialize():
    engine = GridEngine(_make_config(num_grids=10))
    engine.initialize(current_price=100, lower=90, upper=110)

    assert engine.state == GridState.RUNNING
    assert len(engine.levels) == 11  # 10 grids = 11 levels
    assert engine.levels[0] == 90.0
    assert engine.levels[-1] == 110.0
    assert engine.fiat_held == 1000
    assert engine.coin_held == 0.0
    # Should have buy orders below current price
    assert len(engine.buy_levels) > 0
    # All buy levels should be below 100
    for price in engine.buy_levels:
        assert price < 100


def test_buy_fill():
    engine = GridEngine(_make_config(num_grids=4))
    engine.initialize(current_price=100, lower=80, upper=120)

    # Price drops to hit a buy level but stays low (high < any sell level)
    ts = datetime(2024, 1, 1)
    completions = engine.update(current_price=82, low=80, high=85, timestamp=ts, fee_rate=0.001)

    # Buys should have filled but not sells (high=85 < next grid level up)
    assert engine.fiat_held < 1000


def test_complete_cycle():
    engine = GridEngine(_make_config(num_grids=4))
    engine.initialize(current_price=100, lower=80, upper=120)

    ts1 = datetime(2024, 1, 1)
    ts2 = datetime(2024, 1, 2)

    # Buy fill: price drops
    engine.update(current_price=85, low=80, high=90, timestamp=ts1, fee_rate=0.001)
    coins_after_buy = engine.coin_held
    assert coins_after_buy > 0

    # Sell fill: price goes back up
    completions = engine.update(current_price=105, low=95, high=110, timestamp=ts2, fee_rate=0.001)

    # Should have completed at least one cycle
    assert len(completions) >= 1
    assert completions[0].net_profit > 0  # profit from grid spacing
    assert engine.total_profit > 0


def test_multiple_cycles():
    engine = GridEngine(_make_config(num_grids=4))
    engine.initialize(current_price=100, lower=80, upper=120)

    total_completions = 0

    # Simulate oscillation: down, up, down, up
    for i in range(5):
        ts = datetime(2024, 1, i + 1)
        # Drop
        engine.update(current_price=85, low=80, high=90, timestamp=ts, fee_rate=0.001)
        # Rise
        completions = engine.update(current_price=115, low=100, high=120, timestamp=ts, fee_rate=0.001)
        total_completions += len(completions)

    # Should have accumulated profit from multiple cycles
    assert total_completions > 0
    assert engine.total_profit > 0


def test_no_action_when_paused():
    config = _make_config(regime_filter=True)
    engine = GridEngine(config)
    engine.initialize(current_price=100, lower=80, upper=120)

    # Simulate trending market (low choppiness)
    engine.update_regime(choppiness=30, atr=5)
    assert engine.state == GridState.PAUSED
    assert engine.current_regime == MarketRegime.TRENDING

    # Price drops but grid is paused
    ts = datetime(2024, 1, 1)
    completions = engine.update(current_price=85, low=80, high=90, timestamp=ts, fee_rate=0.001)
    assert len(completions) == 0
    assert engine.coin_held == 0  # no fills when paused


def test_regime_resume():
    config = _make_config(regime_filter=True)
    engine = GridEngine(config)
    engine.initialize(current_price=100, lower=80, upper=120)

    # Pause (trending)
    engine.update_regime(choppiness=30, atr=5)
    assert engine.state == GridState.PAUSED

    # Resume (ranging)
    engine.update_regime(choppiness=60, atr=5)
    assert engine.state == GridState.RUNNING


def test_snapshot():
    engine = GridEngine(_make_config(num_grids=4))
    engine.initialize(current_price=100, lower=80, upper=120)

    ts = datetime(2024, 1, 1)
    snapshot = engine.get_snapshot(100, ts)

    assert snapshot.current_price == 100
    assert snapshot.lower_price == 80
    assert snapshot.upper_price == 120
    assert snapshot.investment == 1000
    assert snapshot.state == "running"


def test_rebalance():
    config = _make_config(num_grids=4, rebalance_on_breakout=True, use_atr_spacing=False)
    engine = GridEngine(config)
    engine.initialize(current_price=100, lower=80, upper=120)

    old_levels = engine.levels.copy()

    # Price breaks out above range
    engine.rebalance(current_price=130)

    # Grid should be repositioned
    assert engine.levels != old_levels
    # New grid should be centered around 130
    assert engine.levels[0] < 130 < engine.levels[-1]


def test_value_at_price():
    engine = GridEngine(_make_config())
    engine.fiat_held = 500
    engine.coin_held = 1.0

    assert engine.value_at_price(100) == 600.0
    assert engine.value_at_price(200) == 700.0


# ── Optimization feature tests ──


def test_geometric_spacing():
    """Geometric spacing gives equal % between levels."""
    config = _make_config(num_grids=4, spacing="geometric")
    engine = GridEngine(config)
    engine.initialize(current_price=200, lower=100, upper=400)

    ratios = [engine.levels[i + 1] / engine.levels[i] for i in range(len(engine.levels) - 1)]
    for r in ratios:
        assert abs(r - ratios[0]) < 0.01


def test_weighted_quantities():
    """Weighted mode assigns more coins to lower levels."""
    config = _make_config(num_grids=10, weighted_qty=True)
    engine = GridEngine(config)
    engine.initialize(current_price=100, lower=50, upper=110)

    # Lower buy levels should have higher quantities
    buy_prices = sorted(engine.buy_levels.keys())
    if len(buy_prices) >= 2:
        lowest = engine.buy_levels[buy_prices[0]]
        highest = engine.buy_levels[buy_prices[-1]]
        assert lowest.quantity >= highest.quantity


def test_rsi_filter_blocks_buy():
    """RSI filter prevents buys during extreme oversold (crash protection)."""
    config = _make_config(num_grids=4, rsi_filter=True, rsi_oversold=25.0)
    engine = GridEngine(config)
    engine.initialize(current_price=100, lower=80, upper=120)

    # Set RSI to extreme oversold (crash)
    engine.update_rsi(15.0)

    ts = datetime(2024, 1, 1)
    fiat_before = engine.fiat_held
    engine.update(current_price=85, low=80, high=90, timestamp=ts, fee_rate=0.001)

    # No buys should have executed (RSI too low = falling knife)
    assert engine.fiat_held == fiat_before
    assert engine.coin_held == 0.0


def test_rsi_filter_allows_buy_normal():
    """RSI filter allows buys when RSI is in normal range."""
    config = _make_config(num_grids=4, rsi_filter=True, rsi_oversold=25.0)
    engine = GridEngine(config)
    engine.initialize(current_price=100, lower=80, upper=120)

    # Set RSI to normal
    engine.update_rsi(45.0)

    ts = datetime(2024, 1, 1)
    engine.update(current_price=85, low=80, high=90, timestamp=ts, fee_rate=0.001)

    # Buys should have executed
    assert engine.coin_held > 0


def test_rebalance_cooldown():
    """Rebalance cooldown prevents whipsaw rebalances."""
    config = _make_config(
        num_grids=4, rebalance_on_breakout=True,
        use_atr_spacing=False, rebalance_cooldown=3,
    )
    engine = GridEngine(config)
    engine.initialize(current_price=100, lower=80, upper=120)

    # First rebalance should work (cooldown starts at 999)
    engine.rebalance(current_price=130)
    levels_after_first = engine.levels.copy()

    # Immediate second rebalance should be blocked by cooldown
    engine.rebalance(current_price=150)
    assert engine.levels == levels_after_first  # unchanged


def test_trailing_shift():
    """Trailing shift moves grid up when profits accumulate."""
    config = _make_config(
        num_grids=4, trailing_shift=True,
        trailing_shift_pct=0.01,  # shift after 1% profit
    )
    engine = GridEngine(config)
    engine.initialize(current_price=100, lower=80, upper=120)

    original_lower = engine.levels[0]

    # Simulate profitable cycles: buy low, sell high repeatedly
    for i in range(10):
        ts = datetime(2024, 1, i + 1)
        engine.update(current_price=85, low=80, high=90, timestamp=ts, fee_rate=0.001)
        engine.update(current_price=115, low=100, high=120, timestamp=ts, fee_rate=0.001)

    # If enough profit accumulated, grid should have shifted up
    if engine.total_profit >= engine.initial_investment * 0.01:
        assert engine.levels[0] > original_lower
