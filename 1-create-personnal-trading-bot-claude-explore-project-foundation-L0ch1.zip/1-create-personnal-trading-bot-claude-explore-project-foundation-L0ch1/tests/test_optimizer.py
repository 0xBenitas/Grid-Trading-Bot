"""Tests for the parameter optimizer."""

import numpy as np
import pandas as pd

from src.core.models import GridConfig, BacktestResult
from src.engine.optimizer import optimize, calculate_stability_score, format_report, QUICK_SEARCH_SPACE


def _make_ranging_data(n: int = 500, center: float = 100, amplitude: float = 20, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    t = np.linspace(0, 10 * np.pi, n)
    close = center + amplitude * np.sin(t) + rng.normal(0, 2, n)
    noise = rng.uniform(1, 5, n)

    return pd.DataFrame({
        "open": close + rng.normal(0, 1, n),
        "high": close + noise,
        "low": close - noise,
        "close": close,
        "volume": rng.uniform(100, 1000, n),
    }, index=pd.date_range("2024-01-01", periods=n, freq="h"))


def test_optimize_returns_results():
    """Optimizer should return ranked results."""
    df = _make_ranging_data(n=300)
    config = GridConfig(symbol="TEST", total_investment=1000)

    # Minimal search space for speed
    search_space = {
        "num_grids": [10, 20],
        "atr_multiplier": [2.0],
        "spacing": ["arithmetic"],
        "regime_filter": [False],
        "rsi_filter": [False],
    }

    report = optimize(df, config, search_space=search_space, top_n=5)

    assert report.symbol == "TEST"
    assert report.total_combinations == 2
    assert len(report.results) > 0
    assert report.best is not None
    assert report.best.stability_score >= 0


def test_stability_score_calculation():
    """Stability score should reward ROI and penalize drawdown."""
    from datetime import datetime

    good_result = BacktestResult(
        initial_investment=1000, final_value=1100,
        total_profit=100, total_fees=5,
        roi_pct=10, annualized_roi_pct=20,
        buy_hold_roi_pct=5, vs_hold_pct=5,
        completed_cycles=50, total_buy_fills=50, total_sell_fills=50,
        avg_profit_per_cycle=2, avg_profit_pct_per_cycle=0.2,
        max_drawdown_pct=-3, max_coin_exposure_pct=30,
        max_unrealized_loss=-20,
        start_date=datetime(2024, 1, 1), end_date=datetime(2024, 6, 1),
        duration_days=150, uptime_pct=80,
    )

    bad_result = BacktestResult(
        initial_investment=1000, final_value=900,
        total_profit=10, total_fees=30,
        roi_pct=-10, annualized_roi_pct=-20,
        buy_hold_roi_pct=5, vs_hold_pct=-15,
        completed_cycles=5, total_buy_fills=5, total_sell_fills=5,
        avg_profit_per_cycle=2, avg_profit_pct_per_cycle=0.2,
        max_drawdown_pct=-12, max_coin_exposure_pct=60,
        max_unrealized_loss=-100,
        start_date=datetime(2024, 1, 1), end_date=datetime(2024, 6, 1),
        duration_days=150, uptime_pct=30,
    )

    good_score = calculate_stability_score(good_result)
    bad_score = calculate_stability_score(bad_result)

    assert good_score > bad_score


def test_results_sorted_by_score():
    """Results should be sorted by stability score, best first."""
    df = _make_ranging_data(n=300)
    config = GridConfig(symbol="TEST", total_investment=1000)

    search_space = {
        "num_grids": [5, 10, 20],
        "atr_multiplier": [2.0],
        "spacing": ["arithmetic"],
        "regime_filter": [False],
        "rsi_filter": [False],
    }

    report = optimize(df, config, search_space=search_space, top_n=10)

    scores = [r.stability_score for r in report.results]
    assert scores == sorted(scores, reverse=True)


def test_format_report():
    """Format report should produce readable output."""
    df = _make_ranging_data(n=300)
    config = GridConfig(symbol="TEST", total_investment=1000)

    search_space = {
        "num_grids": [10],
        "atr_multiplier": [2.0],
        "spacing": ["arithmetic"],
        "regime_filter": [False],
        "rsi_filter": [False],
    }

    report = optimize(df, config, search_space=search_space)
    text = format_report(report)

    assert "OPTIMIZATION REPORT" in text
    assert "TEST" in text
    assert "RECOMMENDED CONFIG" in text
