# Grid Trading Bot

Bot de grid trading crypto optimise pour les marches range-bound. Exploite la volatilite laterale en placant des ordres d'achat/vente a intervalles reguliers dans une fourchette de prix.

## Comment ca marche

```
Prix ^
     |  SELL -------- niveau 5
     |  SELL -------- niveau 4
     |  >>> prix actuel <<<
     |  BUY  -------- niveau 2
     |  BUY  -------- niveau 1
     +------------------------> Temps

1. Le bot divise une fourchette de prix en N niveaux
2. Il place des ordres BUY sous le prix actuel
3. Quand un BUY se remplit → place un SELL un niveau au-dessus
4. Quand un SELL se remplit → replace un BUY un niveau en-dessous
5. Chaque cycle BUY→SELL capture l'ecart entre niveaux comme profit
```

## Features

- **Grid dynamique ATR** — la fourchette s'adapte a la volatilite du marche
- **Filtre de regime** — pause automatique en marche trending (Choppiness Index)
- **Rebalancement auto** — repositionne la grille si le prix sort de la fourchette
- **Risk management** — max drawdown, max exposition, circuit breaker
- **Backtesting** — simulation realiste avec fees et slippage sur donnees Binance
- **Dashboard** — interface Dash/Plotly pour backtester visuellement
- **33 tests** — grid engine, backtester, indicateurs, risk manager

## Installation

```bash
pip install -e ".[dev]"
cp .env.example .env  # cles API Binance (optionnel pour backtest)
```

## Utilisation

### Backtest
```bash
python main.py backtest
python main.py backtest --symbol BTCUSDT --grids 30 --investment 5000 --start "01 January 2023"
```

### Dashboard
```bash
python main.py dashboard
# → http://127.0.0.1:8050
```

### Live Trading
```bash
# Configurer .env avec vos cles API Binance
python main.py live
python main.py live --symbol ETHUSDT --grids 20 --investment 1000
```

## Configuration

Tout dans `config/settings.yaml` :

```yaml
grid:
  symbol: ETHUSDT
  num_grids: 20
  total_investment: 1000
  use_atr_spacing: true      # grille adaptative
  atr_multiplier: 2.0        # largeur = prix +/- ATR * mult
  regime_filter: true         # pause en trending
  rebalance_on_breakout: true # recentre si breakout

risk:
  fee_rate: 0.001             # 0.1% Binance spot
  max_drawdown_pct: 0.15      # arret si -15%
  max_position_pct: 0.50      # max 50% en crypto
```

## Architecture

```
src/
├── core/           # Models (GridConfig, GridOrder), enums, utils
├── data/           # Fetcher Binance, indicateurs (ATR, Choppiness, RSI...)
├── engine/         # Grid engine, backtester, risk manager, live trader
├── exchange/       # Interface abstraite + client Binance
└── dashboard/      # Dashboard Dash/Plotly
```

## Tests

```bash
pytest tests/ -v
```
